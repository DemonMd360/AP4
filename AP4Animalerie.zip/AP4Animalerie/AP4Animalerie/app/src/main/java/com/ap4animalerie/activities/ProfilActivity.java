package com.ap4animalerie.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Abonnement;
import com.ap4animalerie.models.Utilisateur;
import com.ap4animalerie.utils.Session;

/**
 * Mon Profil — client.
 * Affiche et modifie nom, prénom, email, ville.
 * Affiche l'abonnement actuel (non modifiable ici).
 */
public class ProfilActivity extends AppCompatActivity {

    private Session   session;
    private EditText  editNom, editPrenom, editEmail, editVille;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("👤 Mon profil");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        session   = new Session(this);
        editNom    = findViewById(R.id.profil_nom);
        editPrenom = findViewById(R.id.profil_prenom);
        editEmail  = findViewById(R.id.profil_email);
        editVille  = findViewById(R.id.profil_ville);

        // Charger les données actuelles
        Utilisateur u = DB.get().getUserById(session.getId());
        if (u != null) {
            editNom.setText(u.nom);
            editPrenom.setText(u.prenom);
            editEmail.setText(u.email);
            editVille.setText(u.ville);
        }

        // Afficher l'abonnement actuel
        Abonnement ab = DB.get().getAbonnementById(session.getIdAbo());
        ((TextView) findViewById(R.id.profil_abonnement))
                .setText("💳 Abonnement : " + (ab != null ? ab.nom + " — " + ab.prix + " €/mois" : "Aucun"));

        // Sauvegarder
        ((Button) findViewById(R.id.profil_btn_sauvegarder)).setOnClickListener(v -> {
            String nom    = editNom.getText().toString().trim();
            String prenom = editPrenom.getText().toString().trim();
            String email  = editEmail.getText().toString().trim();
            String ville  = editVille.getText().toString().trim();

            if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Nom, prénom et email sont obligatoires.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Mettre à jour en local
            DB.get().updateUser(session.getId(), nom, prenom, email, ville);

            // Mettre à jour la session
            session.save(session.getId(), nom, prenom, email, session.getRole(), session.getIdAbo());

            Toast.makeText(this, "Profil mis à jour !", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
