package com.ap4animalerie.data;

import com.ap4animalerie.models.Animal;
import com.ap4animalerie.models.Abonnement;
import com.ap4animalerie.models.Article;
import com.ap4animalerie.models.Utilisateur;

import java.util.ArrayList;
import java.util.List;

/**
 * Base de données locale — toutes les données de l'app.
 * Aucun réseau, aucune API. Tout est ici.
 */
public class DB {

    private static DB instance;

    // ── Données ───────────────────────────────────────────────
    public final List<Utilisateur> utilisateurs = new ArrayList<>();
    public final List<Animal>      animaux      = new ArrayList<>();
    public final List<Abonnement>  abonnements  = new ArrayList<>();
    public final List<Article>     articles     = new ArrayList<>();

    private DB() {
        // Abonnements
        abonnements.add(new Abonnement(1, "Basic",   9.99,  "Accès à la boutique + 1 animal"));
        abonnements.add(new Abonnement(2, "Premium", 19.99, "Accès complet + 5 animaux + réductions"));
        abonnements.add(new Abonnement(3, "VIP",     49.99, "Tout inclus + livraison gratuite + 10 animaux"));

        // Utilisateurs : email / mdp / role(admin ou client)
        utilisateurs.add(new Utilisateur(1, "Admin",   "Super",  "admin@animalerie.fr",  "admin123",  "Admin",  3, "Nîmes"));
        utilisateurs.add(new Utilisateur(2, "Durand",  "Sophie", "sophie@mail.com",       "pass456",   "Client", 2, "Montpellier"));
        utilisateurs.add(new Utilisateur(3, "Petit",   "Lucas",  "lucas@mail.com",        "pass789",   "Client", 1, "Avignon"));
        utilisateurs.add(new Utilisateur(4, "Bernard", "Emma",   "emma@mail.com",         "pass000",   "Client", 2, "Marseille"));

        // Articles boutique
        articles.add(new Article(1, "Croquettes Premium",  12.50, "Alimentation",  "Croquettes pour chien adulte, sac 5kg"));
        articles.add(new Article(2, "Laisse nylon 2m",      8.90, "Accessoires",   "Laisse solide et légère"));
        articles.add(new Article(3, "Gamelle inox",          5.00, "Accessoires",   "Gamelle anti-dérapante"));
        articles.add(new Article(4, "Terrarium 60cm",       80.00, "Habitat",       "Terrarium verre + couvercle grillage"));
        articles.add(new Article(5, "Cage perroquet",      200.00, "Habitat",       "Grande cage avec perchoirs et mangeoires"));
        articles.add(new Article(6, "Foin Timothy 1kg",     4.50, "Alimentation",  "Foin naturel pour lapins et rongeurs"));
        articles.add(new Article(7, "Anti-parasitaire",    15.00, "Santé",         "Traitement mensuel chien/chat"));
        articles.add(new Article(8, "Jouet pour chat",      6.00, "Jouets",        "Baguette avec plumes et grelots"));

        // Animaux
        animaux.add(new Animal(1, "Rex",    "Chien",     "Mammifere", 5,  "Mâle",   "Court",            null, null,    null,   2));
        animaux.add(new Animal(2, "Mina",   "Chat",      "Mammifere", 2,  "Femelle","Long soyeux",       null, null,    null,   2));
        animaux.add(new Animal(3, "Drako",  "Iguane",    "Reptile",   4,  "Mâle",   null, "Granuleuses", 0,    null,    null,   1));
        animaux.add(new Animal(4, "Cobra",  "Cobra",     "Reptile",   7,  "Mâle",   null, "Lisses",      1,    null,    null,   1));
        animaux.add(new Animal(5, "Kiko",   "Perroquet", "Oiseau",    1,  "Mâle",   null, null,          null, 95.5,   "Oui",  3));
        animaux.add(new Animal(6, "Tweety", "Canari",    "Oiseau",    3,  "Femelle",null, null,          null, 22.0,   "Oui",  4));
        animaux.add(new Animal(7, "Luna",   "Husky",     "Mammifere", 3,  "Femelle","Épais",             null, null,    null,   4));
        animaux.add(new Animal(8, "Gecko",  "Gecko",     "Reptile",   2,  "Femelle",null, "Granuleuses", 0,    null,    null,   3));
    }

    public static DB get() {
        if (instance == null) instance = new DB();
        return instance;
    }

    // ── Méthodes utiles ───────────────────────────────────────

    public Utilisateur login(String email, String mdp) {
        for (Utilisateur u : utilisateurs)
            if (u.email.equalsIgnoreCase(email.trim()) && u.mdp.equals(mdp.trim()))
                return u;
        return null;
    }

    public Utilisateur getUserById(int id) {
        for (Utilisateur u : utilisateurs) if (u.id == id) return u;
        return null;
    }

    public Abonnement getAbonnementById(int id) {
        for (Abonnement a : abonnements) if (a.id == id) return a;
        return null;
    }

    public List<Animal> getAnimauxByType(String type) {
        if (type == null || type.equals("Tous")) return new ArrayList<>(animaux);
        List<Animal> r = new ArrayList<>();
        for (Animal a : animaux) if (a.type.equals(type)) r.add(a);
        return r;
    }

    public List<Animal> getAnimauxByUser(int idUser) {
        List<Animal> r = new ArrayList<>();
        for (Animal a : animaux) if (a.idProprietaire == idUser) r.add(a);
        return r;
    }

    public Animal getAnimalById(int id) {
        for (Animal a : animaux) if (a.id == id) return a;
        return null;
    }

    public void addAnimal(Animal a) { animaux.add(a); }

    public void deleteAnimal(int id) {
        for (int i = 0; i < animaux.size(); i++)
            if (animaux.get(i).id == id) { animaux.remove(i); return; }
    }

    public void updateAnimal(int id, String nom, String espece, int age, String sexe) {
        for (Animal a : animaux) if (a.id == id) {
            a.nom = nom; a.espece = espece; a.age = age; a.sexe = sexe; return;
        }
    }

    public void updateUser(int id, String nom, String prenom, String email, String ville) {
        for (Utilisateur u : utilisateurs) if (u.id == id) {
            u.nom = nom; u.prenom = prenom; u.email = email; u.ville = ville; return;
        }
    }

    public int nextAnimalId() {
        int max = 0;
        for (Animal a : animaux) if (a.id > max) max = a.id;
        return max + 1;
    }

    public List<Article> getArticlesByCategorie(String cat) {
        if (cat == null || cat.equals("Tout")) return new ArrayList<>(articles);
        List<Article> r = new ArrayList<>();
        for (Article a : articles) if (a.categorie.equals(cat)) r.add(a);
        return r;
    }
}
