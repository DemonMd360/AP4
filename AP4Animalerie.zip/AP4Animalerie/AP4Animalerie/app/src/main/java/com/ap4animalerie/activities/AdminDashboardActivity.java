package com.ap4animalerie.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.utils.Session;

/**
 * Tableau de bord Admin.
 * Stats + accès CRUD animaux, gestion utilisateurs.
 */
public class AdminDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        Session s = new Session(this);
        if (!s.isLogged() || !s.isAdmin()) {
            startActivity(new Intent(this, LoginActivity.class)); finish(); return;
        }

        if (getSupportActionBar() != null) getSupportActionBar().setTitle("⚙️ Admin");

        refreshStats();

        // Navigation
        findViewById(R.id.admin_btn_animaux).setOnClickListener(v ->
                startActivity(new Intent(this, AdminAnimauxActivity.class)));

        findViewById(R.id.admin_btn_utilisateurs).setOnClickListener(v ->
                startActivity(new Intent(this, AdminUtilisateursActivity.class)));

        findViewById(R.id.admin_btn_boutique).setOnClickListener(v ->
                startActivity(new Intent(this, BoutiqueActivity.class)));

        findViewById(R.id.admin_btn_abonnements).setOnClickListener(v ->
                startActivity(new Intent(this, AbonnementsActivity.class)));

        findViewById(R.id.admin_btn_deconnexion).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Déconnexion")
                        .setMessage("Confirmer ?")
                        .setPositiveButton("Oui", (d, w) -> {
                            s.logout();
                            startActivity(new Intent(this, LoginActivity.class));
                            finish();
                        })
                        .setNegativeButton("Non", null).show());
    }

    @Override
    protected void onResume() { super.onResume(); refreshStats(); }

    private void refreshStats() {
        DB db = DB.get();
        ((TextView) findViewById(R.id.admin_stat_animaux)).setText(String.valueOf(db.animaux.size()));
        ((TextView) findViewById(R.id.admin_stat_users)).setText(String.valueOf(db.utilisateurs.size()));
        ((TextView) findViewById(R.id.admin_stat_articles)).setText(String.valueOf(db.articles.size()));
        ((TextView) findViewById(R.id.admin_stat_abos)).setText(String.valueOf(db.abonnements.size()));
    }
}
