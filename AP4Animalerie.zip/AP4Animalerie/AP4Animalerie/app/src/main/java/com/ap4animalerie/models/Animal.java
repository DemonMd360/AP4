package com.ap4animalerie.models;

public class Animal {
    public int    id, age, idProprietaire;
    public String nom, espece, type, sexe;
    // Mammifere
    public String pelage;
    // Reptile
    public String typeEcailles;
    public Integer estVenimeux;
    // Oiseau
    public Double  envergure;
    public String  peutVoler;

    public Animal(int id, String nom, String espece, String type, int age, String sexe,
                  String pelage, String typeEcailles, Integer estVenimeux,
                  Double envergure, String peutVoler, int idProprietaire) {
        this.id = id; this.nom = nom; this.espece = espece; this.type = type;
        this.age = age; this.sexe = sexe; this.pelage = pelage;
        this.typeEcailles = typeEcailles; this.estVenimeux = estVenimeux;
        this.envergure = envergure; this.peutVoler = peutVoler;
        this.idProprietaire = idProprietaire;
    }

    public String getEmoji() {
        switch (type) {
            case "Mammifere": return "🐾";
            case "Reptile":   return "🦎";
            case "Oiseau":    return "🐦";
            default:          return "🐾";
        }
    }
}
