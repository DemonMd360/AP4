package com.ap4animalerie.activities;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Animal;

import java.util.List;

/**
 * CRUD Animaux pour l'Admin.
 * ListView + boutons Ajouter / Modifier / Supprimer.
 */
public class AdminAnimauxActivity extends AppCompatActivity {

    private ListView     listView;
    private List<Animal> animaux;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_animaux);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("🐾 Gestion Animaux");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        listView = findViewById(R.id.admin_animaux_list);
        refreshList();

        // Clic long → modifier / supprimer
        listView.setOnItemLongClickListener((parent, view, pos, id) -> {
            Animal a = animaux.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle(a.nom)
                    .setItems(new String[]{"✏️ Modifier", "🗑 Supprimer"}, (d, which) -> {
                        if (which == 0) showFormModifier(a);
                        else confirmerSupprimer(a);
                    }).show();
            return true;
        });

        // Bouton ajouter
        findViewById(R.id.admin_animaux_btn_ajouter).setOnClickListener(v -> showFormAjouter());
    }

    private void refreshList() {
        animaux = DB.get().animaux;
        String[] items = new String[animaux.size()];
        for (int i = 0; i < animaux.size(); i++) {
            Animal a = animaux.get(i);
            items[i] = a.getEmoji() + " " + a.nom + " — " + a.espece + " (" + a.type + ") — " + a.age + " ans";
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
    }

    // ── Formulaire Ajouter ────────────────────────────────────
    private void showFormAjouter() {
        View form = LayoutInflater.from(this).inflate(R.layout.form_animal, null);
        EditText editNom    = form.findViewById(R.id.form_nom);
        EditText editEspece = form.findViewById(R.id.form_espece);
        EditText editAge    = form.findViewById(R.id.form_age);
        Spinner  spinType   = form.findViewById(R.id.form_type);
        Spinner  spinSexe   = form.findViewById(R.id.form_sexe);

        new AlertDialog.Builder(this)
                .setTitle("➕ Ajouter un animal")
                .setView(form)
                .setPositiveButton("Ajouter", (d, w) -> {
                    String nom    = editNom.getText().toString().trim();
                    String espece = editEspece.getText().toString().trim();
                    String ageStr = editAge.getText().toString().trim();
                    String type   = spinType.getSelectedItem().toString();
                    String sexe   = spinSexe.getSelectedItem().toString();

                    if (nom.isEmpty() || espece.isEmpty() || ageStr.isEmpty()) {
                        Toast.makeText(this, "Remplissez tous les champs", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int age = Integer.parseInt(ageStr);
                    Animal a = new Animal(DB.get().nextAnimalId(), nom, espece, type, age, sexe,
                            null, null, null, null, null, 1);
                    DB.get().addAnimal(a);
                    refreshList();
                    Toast.makeText(this, "Animal ajouté !", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    // ── Formulaire Modifier ───────────────────────────────────
    private void showFormModifier(Animal a) {
        View form = LayoutInflater.from(this).inflate(R.layout.form_animal, null);
        EditText editNom    = form.findViewById(R.id.form_nom);
        EditText editEspece = form.findViewById(R.id.form_espece);
        EditText editAge    = form.findViewById(R.id.form_age);

        editNom.setText(a.nom);
        editEspece.setText(a.espece);
        editAge.setText(String.valueOf(a.age));

        new AlertDialog.Builder(this)
                .setTitle("✏️ Modifier " + a.nom)
                .setView(form)
                .setPositiveButton("Enregistrer", (d, w) -> {
                    String nom    = editNom.getText().toString().trim();
                    String espece = editEspece.getText().toString().trim();
                    String ageStr = editAge.getText().toString().trim();
                    if (nom.isEmpty() || espece.isEmpty() || ageStr.isEmpty()) return;
                    DB.get().updateAnimal(a.id, nom, espece, Integer.parseInt(ageStr), a.sexe);
                    refreshList();
                    Toast.makeText(this, "Modifié !", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    // ── Supprimer ─────────────────────────────────────────────
    private void confirmerSupprimer(Animal a) {
        new AlertDialog.Builder(this)
                .setTitle("Supprimer " + a.nom + " ?")
                .setMessage("Cette action est irréversible.")
                .setPositiveButton("Supprimer", (d, w) -> {
                    DB.get().deleteAnimal(a.id);
                    refreshList();
                    Toast.makeText(this, "Supprimé.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
