package com.ap4animalerie.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Utilisateur;
import com.ap4animalerie.utils.Session;

/**
 * Connexion — email + mot de passe, aucun réseau.
 * Comptes : admin@animalerie.fr/admin123 (Admin)
 *           sophie@mail.com/pass456 (Client)
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Session session = new Session(this);
        if (session.isLogged()) { goNext(session); return; }

        setContentView(R.layout.activity_login);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        EditText editEmail = findViewById(R.id.login_email);
        EditText editMdp   = findViewById(R.id.login_mdp);
        Button   btnLogin  = findViewById(R.id.login_btn);

        btnLogin.setOnClickListener(v -> {
            String email = editEmail.getText().toString().trim();
            String mdp   = editMdp.getText().toString().trim();

            if (email.isEmpty() || mdp.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_champs_vides), Toast.LENGTH_SHORT).show();
                return;
            }

            Utilisateur u = DB.get().login(email, mdp);
            if (u == null) {
                Toast.makeText(this, getString(R.string.error_connexion), Toast.LENGTH_SHORT).show();
                return;
            }

            session.save(u.id, u.nom, u.prenom, u.email, u.role, u.idAbonnement);
            Toast.makeText(this, "Bienvenue " + u.prenom + " !", Toast.LENGTH_SHORT).show();
            goNext(session);
        });
    }

    private void goNext(Session s) {
        startActivity(new Intent(this, s.isAdmin() ? AdminDashboardActivity.class : AccueilActivity.class));
        finish();
    }
}
