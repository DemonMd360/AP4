package com.ap4animalerie.models;

public class Abonnement {
    public int    id;
    public String nom, description;
    public double prix;

    public Abonnement(int id, String nom, double prix, String description) {
        this.id = id; this.nom = nom; this.prix = prix; this.description = description;
    }
}
