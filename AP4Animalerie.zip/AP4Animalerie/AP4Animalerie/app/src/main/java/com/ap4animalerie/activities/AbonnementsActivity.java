package com.ap4animalerie.activities;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Abonnement;
import com.ap4animalerie.utils.Session;
import java.util.List;

/**
 * Page Abonnements — affiche les formules disponibles.
 * Indique l'abonnement actuel du client connecté.
 */
public class AbonnementsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abonnements);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("💳 Abonnements");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        Session          session      = new Session(this);
        List<Abonnement> abonnements  = DB.get().abonnements;
        int              idAboActuel  = session.getIdAbo();

        String[] items = new String[abonnements.size()];
        for (int i = 0; i < abonnements.size(); i++) {
            Abonnement ab = abonnements.get(i);
            String actuel = (ab.id == idAboActuel) ? " ✅ (votre formule)" : "";
            items[i] = "💳 " + ab.nom + actuel
                     + "\n   " + ab.prix + " €/mois"
                     + "\n   " + ab.description;
        }

        ListView listView = findViewById(R.id.abonnements_list);
        listView.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items));

        listView.setOnItemClickListener((parent, view, pos, id) -> {
            Abonnement ab = abonnements.get(pos);
            Toast.makeText(this,
                    "Formule : " + ab.nom + "\n" + ab.prix + " €/mois\n" + ab.description,
                    Toast.LENGTH_LONG).show();
        });
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
