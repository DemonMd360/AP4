package com.ap4animalerie.models;

public class Utilisateur {
    public int    id;
    public String nom, prenom, email, mdp, role, ville;
    public int    idAbonnement;

    public Utilisateur(int id, String nom, String prenom, String email,
                       String mdp, String role, int idAbonnement, String ville) {
        this.id = id; this.nom = nom; this.prenom = prenom;
        this.email = email; this.mdp = mdp; this.role = role;
        this.idAbonnement = idAbonnement; this.ville = ville;
    }

    public String getNomComplet() { return prenom + " " + nom; }
    public String getInitiale()   { return prenom.isEmpty() ? "?" : String.valueOf(prenom.charAt(0)).toUpperCase(); }
    public boolean isAdmin()      { return "Admin".equals(role); }
}
