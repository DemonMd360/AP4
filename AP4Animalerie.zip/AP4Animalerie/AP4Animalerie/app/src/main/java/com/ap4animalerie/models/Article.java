package com.ap4animalerie.models;

public class Article {
    public int    id;
    public String nom, categorie, description;
    public double prix;

    public Article(int id, String nom, double prix, String categorie, String description) {
        this.id = id; this.nom = nom; this.prix = prix;
        this.categorie = categorie; this.description = description;
    }
}
