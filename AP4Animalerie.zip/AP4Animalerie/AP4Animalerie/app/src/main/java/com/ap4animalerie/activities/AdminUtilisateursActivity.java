package com.ap4animalerie.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Abonnement;
import com.ap4animalerie.models.Utilisateur;
import java.util.List;

/**
 * Gestion des utilisateurs pour l'Admin.
 * ListView + clic long pour modifier.
 */
public class AdminUtilisateursActivity extends AppCompatActivity {

    private ListView            listView;
    private List<Utilisateur>   users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_utilisateurs);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("👤 Utilisateurs");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        listView = findViewById(R.id.admin_users_list);
        refreshList();

        listView.setOnItemLongClickListener((parent, view, pos, id) -> {
            Utilisateur u = users.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle(u.getNomComplet())
                    .setItems(new String[]{"✏️ Modifier"}, (d, which) -> showFormModifier(u))
                    .show();
            return true;
        });
    }

    private void refreshList() {
        users = DB.get().utilisateurs;
        String[] items = new String[users.size()];
        for (int i = 0; i < users.size(); i++) {
            Utilisateur u   = users.get(i);
            Abonnement  ab  = DB.get().getAbonnementById(u.idAbonnement);
            String      abo = ab != null ? ab.nom : "Aucun";
            items[i] = u.getInitiale() + " " + u.getNomComplet()
                     + " [" + u.role + "] — " + u.email
                     + "\n   📍 " + u.ville + " | 💳 " + abo;
        }
        listView.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items));
    }

    private void showFormModifier(Utilisateur u) {
        View form = LayoutInflater.from(this).inflate(R.layout.form_utilisateur, null);
        EditText editNom    = form.findViewById(R.id.form_user_nom);
        EditText editPrenom = form.findViewById(R.id.form_user_prenom);
        EditText editEmail  = form.findViewById(R.id.form_user_email);
        EditText editVille  = form.findViewById(R.id.form_user_ville);

        editNom.setText(u.nom);
        editPrenom.setText(u.prenom);
        editEmail.setText(u.email);
        editVille.setText(u.ville);

        new AlertDialog.Builder(this)
                .setTitle("✏️ Modifier " + u.getNomComplet())
                .setView(form)
                .setPositiveButton("Enregistrer", (d, w) -> {
                    String nom    = editNom.getText().toString().trim();
                    String prenom = editPrenom.getText().toString().trim();
                    String email  = editEmail.getText().toString().trim();
                    String ville  = editVille.getText().toString().trim();
                    if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty()) {
                        Toast.makeText(this, "Remplissez tous les champs", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    DB.get().updateUser(u.id, nom, prenom, email, ville);
                    refreshList();
                    Toast.makeText(this, "Utilisateur modifié !", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
