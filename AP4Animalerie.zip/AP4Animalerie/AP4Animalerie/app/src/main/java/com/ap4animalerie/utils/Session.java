package com.ap4animalerie.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class Session {
    private static final String PREF = "session";
    private final SharedPreferences p;
    private final SharedPreferences.Editor e;

    public Session(Context ctx) {
        p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        e = p.edit();
    }

    public void save(int id, String nom, String prenom, String email, String role, int idAbo) {
        e.putBoolean("ok", true).putInt("id", id)
         .putString("nom", nom).putString("prenom", prenom)
         .putString("email", email).putString("role", role)
         .putInt("abo", idAbo).apply();
    }

    public boolean isLogged()   { return p.getBoolean("ok", false); }
    public int     getId()      { return p.getInt("id", 0); }
    public String  getNom()     { return p.getString("nom", ""); }
    public String  getPrenom()  { return p.getString("prenom", ""); }
    public String  getEmail()   { return p.getString("email", ""); }
    public String  getRole()    { return p.getString("role", "Client"); }
    public int     getIdAbo()   { return p.getInt("abo", 0); }
    public boolean isAdmin()    { return "Admin".equals(getRole()); }
    public String  fullName()   { return getPrenom() + " " + getNom(); }
    public void    logout()     { e.clear().apply(); }
}
