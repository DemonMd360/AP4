package com.ap4animalerie.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.utils.Session;

/**
 * Page d'accueil pour les clients.
 * Menu : Mes animaux | Boutique | Abonnements | Mon profil
 */
public class AccueilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil);

        Session s = new Session(this);
        if (!s.isLogged()) { startActivity(new Intent(this, LoginActivity.class)); finish(); return; }

        if (getSupportActionBar() != null) getSupportActionBar().setTitle("🐾 Animalerie");

        ((TextView) findViewById(R.id.accueil_bienvenue))
                .setText("Bonjour, " + s.getPrenom() + " 👋");

        findViewById(R.id.accueil_btn_animaux).setOnClickListener(v ->
                startActivity(new Intent(this, AnimauxActivity.class)));

        findViewById(R.id.accueil_btn_boutique).setOnClickListener(v ->
                startActivity(new Intent(this, BoutiqueActivity.class)));

        findViewById(R.id.accueil_btn_abonnements).setOnClickListener(v ->
                startActivity(new Intent(this, AbonnementsActivity.class)));

        findViewById(R.id.accueil_btn_profil).setOnClickListener(v ->
                startActivity(new Intent(this, ProfilActivity.class)));

        findViewById(R.id.accueil_btn_deconnexion).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Déconnexion")
                        .setMessage("Confirmer la déconnexion ?")
                        .setPositiveButton("Oui", (d, w) -> {
                            s.logout();
                            startActivity(new Intent(this, LoginActivity.class));
                            finish();
                        })
                        .setNegativeButton("Non", null).show());
    }
}
