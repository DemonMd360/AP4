package com.ap4animalerie.activities;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Article;
import java.util.List;

/**
 * Boutique — liste des articles avec filtres par catégorie.
 * Clic sur un article → Toast avec le détail.
 */
public class BoutiqueActivity extends AppCompatActivity {

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boutique);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("🛒 Boutique");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        listView = findViewById(R.id.boutique_list);

        // Boutons de filtre
        findViewById(R.id.boutique_btn_tout).setOnClickListener(v ->         loadArticles(null));
        findViewById(R.id.boutique_btn_alimentation).setOnClickListener(v -> loadArticles("Alimentation"));
        findViewById(R.id.boutique_btn_accessoires).setOnClickListener(v ->  loadArticles("Accessoires"));
        findViewById(R.id.boutique_btn_habitat).setOnClickListener(v ->      loadArticles("Habitat"));
        findViewById(R.id.boutique_btn_sante).setOnClickListener(v ->        loadArticles("Santé"));

        loadArticles(null);
    }

    private void loadArticles(String categorie) {
        List<Article> articles = DB.get().getArticlesByCategorie(categorie);
        String[] items = new String[articles.size()];
        for (int i = 0; i < articles.size(); i++) {
            Article a = articles.get(i);
            items[i] = "🏷️ " + a.nom + "\n   " + a.categorie + " — " + a.prix + " €";
        }
        listView.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items));

        listView.setOnItemClickListener((parent, view, pos, id) -> {
            Article a = articles.get(pos);
            Toast.makeText(this,
                    a.nom + "\n" + a.description + "\nPrix : " + a.prix + " €",
                    Toast.LENGTH_LONG).show();
        });
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
