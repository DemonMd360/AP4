package com.ap4animalerie.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.ap4animalerie.R;
import com.ap4animalerie.data.DB;
import com.ap4animalerie.models.Animal;
import com.ap4animalerie.utils.Session;
import java.util.List;

/**
 * Mes Animaux — page client.
 * Affiche les animaux de l'utilisateur connecté.
 * Permet d'en ajouter ou d'en supprimer.
 */
public class AnimauxActivity extends AppCompatActivity {

    private ListView     listView;
    private List<Animal> animaux;
    private Session      session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animaux);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("🐾 Mes animaux");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        session = new Session(this);
        listView = findViewById(R.id.animaux_list);
        refreshList();

        // Clic long → supprimer
        listView.setOnItemLongClickListener((parent, view, pos, id) -> {
            Animal a = animaux.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle("Supprimer " + a.nom + " ?")
                    .setPositiveButton("Supprimer", (d, w) -> {
                        DB.get().deleteAnimal(a.id);
                        refreshList();
                        Toast.makeText(this, "Animal supprimé.", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Annuler", null)
                    .show();
            return true;
        });

        findViewById(R.id.animaux_btn_ajouter).setOnClickListener(v -> showFormAjouter());
    }

    private void refreshList() {
        animaux = DB.get().getAnimauxByUser(session.getId());
        String[] items = new String[animaux.size()];
        for (int i = 0; i < animaux.size(); i++) {
            Animal a = animaux.get(i);
            items[i] = a.getEmoji() + " " + a.nom + " — " + a.espece
                     + "\n   " + a.type + " | " + a.age + " ans | " + a.sexe;
        }
        if (items.length == 0) {
            listView.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1,
                    new String[]{"Aucun animal enregistré.\nAppuyez sur + pour en ajouter un."}));
        } else {
            listView.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, items));
        }
    }

    private void showFormAjouter() {
        View form = LayoutInflater.from(this).inflate(R.layout.form_animal, null);
        EditText editNom    = form.findViewById(R.id.form_nom);
        EditText editEspece = form.findViewById(R.id.form_espece);
        EditText editAge    = form.findViewById(R.id.form_age);
        Spinner  spinType   = form.findViewById(R.id.form_type);
        Spinner  spinSexe   = form.findViewById(R.id.form_sexe);

        new AlertDialog.Builder(this)
                .setTitle("➕ Ajouter un animal")
                .setView(form)
                .setPositiveButton("Ajouter", (d, w) -> {
                    String nom    = editNom.getText().toString().trim();
                    String espece = editEspece.getText().toString().trim();
                    String ageStr = editAge.getText().toString().trim();
                    if (nom.isEmpty() || espece.isEmpty() || ageStr.isEmpty()) {
                        Toast.makeText(this, "Remplissez tous les champs", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Animal a = new Animal(
                            DB.get().nextAnimalId(), nom, espece,
                            spinType.getSelectedItem().toString(),
                            Integer.parseInt(ageStr),
                            spinSexe.getSelectedItem().toString(),
                            null, null, null, null, null,
                            session.getId());
                    DB.get().addAnimal(a);
                    refreshList();
                    Toast.makeText(this, "Animal ajouté !", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
